<?php
if($_SERVER['REQUEST_METHOD'] != "POST")
{
    $response['status'] = "error";
    $response['message'] = "invalid request method";
    $responseJSON = json_encode($response);
    die($responseJSON);
}

if(isset($_POST['signup']))
{
    //do signup
    $hmi = new hmicontroller("023");
    //check if post data are correctly set
    $response = $hmi->signUp(
        $_POST['lastname'],
        $_POST['firstname'],
        $_POST['middlename'],
        $_POST['gender'],
        $_POST['maritalstatus'],
        $_POST['telno'],
        $_POST['pemail'],
        $_POST['oemail'],
        $_POST['address'],
        $_POST['dep'],
        $_POST['designation'],
        $_POST['employmenttype'],
        $_POST['cert'],
        $_POST['cor'],
        $_POST['nok'],
        $_POST['nokn'],
        $_POST['noka'],
        $_POST['branch'],
        $_POST['dob'],
        $_POST['salaryacc'],
        $_POST['bankofacc'],
        $_POST['pfname'],
        $_POST['rsapin'],
        $_POST['password']
        );
        die($response);
}


