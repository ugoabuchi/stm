<?php

class hmiinterface
{
    private $staff = null;
    
    
    function __construct($staffid)
    {
        $this->staff = array(
            "staffid" => $staffid
        );
    }

    public function setStaff($staff)
    {
        $this->staff = array_merge($this->staff,$staff);
    }

    public function getStaff()
    {
        return $this->staff;
    }

}