<?php
$hmi = new hmicontroller("023");
//echo $hmi->signUp("Mathew","Fortune","Ugochukwu","Male","Single","09083273485","mathewfortune54@gmail.com","fortune.mathew@nexttechnigeria.com","no 19 oyewole road, iyanaipaja, Lagos","IT","Software Administrator","Full Time","BSC in Computer-Science","Second Class Upper","Mathew Noble","08172532528","no 28 akinfemi street, agege, Lagos","Head Office","1995-12-26","0223951393","GTBANK","Mathew Fortune","PEN10023454351","2018-09-04");
echo $hmi->logIn("MATHEW")."\n";
//$hmi->logout()."\n";
echo print_r($_SESSION);
//echo $hmi->updateProfileimage("img/me.jpg")."\n";
//echo $hmi->getProfileImage("23");