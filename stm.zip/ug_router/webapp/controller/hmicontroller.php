<?php

class hmicontroller
{
    private $hmiobject = null;
    private $session = null;
    private $stafffb = null;

    function __construct($staffid)
    {
        $this->hmiobject = new hmiinterface($staffid);
        $this->session = new session();
        $this->stafffb = new database("stm");
    }

    public function signUp($lastname,$firstname,$middlename,$gender,$maritalstat,$mobileno,$personalemail,$officialemail,$residentaddress,$department,$designation,$employmenttype,$certificate,$classofresult,$nok,$noknumber,$nokaddress,$branch,$dob,$salaryacc,$bankofacc,$pfaname,$rsapin,$resumptiondate)
    {
        $responseJSON = null;

        if($lastname != "")
        {
            $staff = array(

                "lastname" => $lastname,
                "firstname" => $firstname,
                "middlename" => $middlename,
                "fullname" => $lastname." ".$firstname." ".$middlename,
                "gender" => $gender,
                "maritalstatus" => $maritalstat,
                "mobileno" => $mobileno,
                "personalemail" => $personalemail,
                "officialemail" => $officialemail,
                "residentaddress" => $residentaddress,
                "department" => $department,
                "designation" => $designation,
                "employmenttype" => $employmenttype,
                "certificate" => $certificate,
                "classofresult" => $classofresult,
                "nok" => $nok,
                "noknumber" => $noknumber,
                "nokaddress" => $nokaddress,
                "branch" => $branch,
                "dob" => $dob,
                "salaryacc" => $salaryacc,
                "bankofacc" => $bankofacc,
                "pfaname" => $pfaname,
                "rsapin" => $rsapin,
                "resumptiondate" => $resumptiondate,
                "password" => base64_encode(password_hash(strtoupper($lastname), PASSWORD_DEFAULT))
    
            );
    
            $this->hmiobject->setStaff($staff);
    
            //check if staff table exist in database
    
            if($this->stafffb->execute_count_table_no_return("hmi") == 0)
            {
    
                $createstafftablesql = "CREATE TABLE `hmi` ( 
                    `staffid` INT(16) NOT NULL , 
                    `img` VARCHAR(160) NULL ,
                    `lastname` VARCHAR(160) NOT NULL , 
                    `firstname` VARCHAR(160) NOT NULL , 
                    `middlename` VARCHAR(160) NOT NULL , 
                    `fullname` VARCHAR(160) NOT NULL , 
                    `gender` VARCHAR(160) NOT NULL , 
                    `ms` VARCHAR(160) NOT NULL , 
                    `mn` VARCHAR(160) NOT NULL , 
                    `pe` VARCHAR(160) NOT NULL , 
                    `oe` VARCHAR(160) NOT NULL , 
                    `re` TEXT NOT NULL , 
                    `dep` VARCHAR(160) NOT NULL , 
                    `des` VARCHAR(160) NOT NULL , 
                    `emp` VARCHAR(160) NOT NULL , 
                    `cert` VARCHAR(160) NOT NULL , 
                    `cor` VARCHAR(160) NOT NULL , 
                    `nok` VARCHAR(160) NOT NULL , 
                    `nokm` VARCHAR(160) NOT NULL , 
                    `noka` VARCHAR(160) NOT NULL , 
                    `branch` TEXT NOT NULL , 
                    `dob` DATE NOT NULL , 
                    `sacc` VARCHAR(160) NOT NULL , 
                    `bacc` VARCHAR(160) NOT NULL , 
                    `pfaname` VARCHAR(160) NOT NULL , 
                    `rsapin` VARCHAR(160) NOT NULL , 
                    `resdate` DATE NOT NULL , 
                    `password` TEXT NOT NULL , 
                    PRIMARY KEY (`staffid`)) ENGINE = InnoDB;";
    
                $this->stafffb->execute_no_return($createstafftablesql);
            }
    
            //check if staff exist
            $staffid = $this->hmiobject->getStaff()["staffid"];
            $checkstaffsql = "SELECT COUNT(*) FROM `hmi` WHERE staffid='$staffid'";
            if($this->stafffb->execute_count_no_return($checkstaffsql) == 1)
            {
                $response['status'] = "error";
                $response['message'] = "MIV-".$this->hmiobject->getStaff()["staffid"]." already exist";
                $responseJSON = json_encode($response);
            }
            else
            {
                //save new staff
                $staff = "";
                $staffvalues = array_values($this->hmiobject->getStaff());
                $count = 0;
                foreach( $staffvalues as $value)
                {
                    if($count == 0)
                    {
                        $staff = "'".$value."'";
                        $count = 1;
                    }
                    else
                    {
                        $staff .= ",'".$value."'";
                    }
                }
                
                $savestaffsql = "INSERT INTO `hmi`(
                    `staffid`, 
                    `lastname`, 
                    `firstname`, 
                    `middlename`, 
                    `fullname`, 
                    `gender`, 
                    `ms`, 
                    `mn`, 
                    `pe`, 
                    `oe`, 
                    `re`, 
                    `dep`, 
                    `des`, 
                    `emp`, 
                    `cert`, 
                    `cor`, 
                    `nok`, 
                    `nokm`, 
                    `noka`, 
                    `branch`, 
                    `dob`, 
                    `sacc`, 
                    `bacc`, 
                    `pfaname`, 
                    `rsapin`, 
                    `resdate`, 
                    `password`) VALUES ($staff)";
                $this->stafffb->execute_no_return($savestaffsql);
    
                $response['status'] = "success";
                $response['message'] = $this->hmiobject->getStaff()["fullname"]." successfully added with staff id - MIV-".$this->hmiobject->getStaff()["staffid"];
                $response['staffid'] = $this->hmiobject->getStaff()["staffid"];
                $responseJSON = json_encode($response);
                
            }
        }
        else
        {
            $response['status'] = "error";
                $response['message'] = "invalid form data, cross-check your inputs";
                $responseJSON = json_encode($response);
        }

        return $responseJSON;

    }

    public function logIn($password)
    {
        //check if staff table is created

        if($this->stafffb->execute_count_table_no_return("hmi") == 0)
        {
            $createstafftablesql = "CREATE TABLE `hmi` ( 
                `staffid` INT(16) NOT NULL AUTO_INCREMENT , 
                `lastname` VARCHAR(160) NOT NULL , 
                `firstname` VARCHAR(160) NOT NULL , 
                `middlename` VARCHAR(160) NOT NULL , 
                `fullname` VARCHAR(160) NOT NULL , 
                `gender` VARCHAR(160) NOT NULL , 
                `ms` VARCHAR(160) NOT NULL , 
                `mn` VARCHAR(160) NOT NULL , 
                `pe` VARCHAR(160) NOT NULL , 
                `oe` VARCHAR(160) NOT NULL , 
                `re` TEXT NOT NULL , 
                `dep` VARCHAR(160) NOT NULL , 
                `des` VARCHAR(160) NOT NULL , 
                `emp` VARCHAR(160) NOT NULL , 
                `cert` VARCHAR(160) NOT NULL , 
                `cor` VARCHAR(160) NOT NULL , 
                `nok` VARCHAR(160) NOT NULL , 
                `nokm` VARCHAR(160) NOT NULL , 
                `noka` VARCHAR(160) NOT NULL , 
                `branch` TEXT NOT NULL , 
                `dob` DATE NOT NULL , 
                `sacc` VARCHAR(160) NOT NULL , 
                `bacc` VARCHAR(160) NOT NULL , 
                `pfaname` VARCHAR(160) NOT NULL , 
                `rsapin` VARCHAR(160) NOT NULL , 
                `resdate` DATE NOT NULL , 
                `password` TEXT NOT NULL , 
                PRIMARY KEY (`staffid`)) ENGINE = InnoDB;";

            $this->stafffb->execute_no_return($createstafftablesql);
        }


        //check if staffid exit
        //check if staff exist
        $staffid = $this->hmiobject->getStaff()["staffid"];
        $checkstaffsql = "SELECT COUNT(*) FROM `hmi` WHERE staffid='$staffid'";
        if($this->stafffb->execute_count_no_return($checkstaffsql) == 0)
        {
            $this->session->deleteLoginSession();
            $response['status'] = "error";
            $response['message'] = "Staff with MIV-".$this->hmiobject->getStaff()["staffid"]." does not exist";
            $responseJSON = json_encode($response);
            return $responseJSON;
        }
        else
        {
            //check password
            $getdetailssql = "SELECT `lastname`,`oe`,`password` FROM `hmi` WHERE staffid='$staffid'";
            $datavalues = $this->stafffb->execute_return($getdetailssql)[0];
            $staffsavedpassword = $datavalues['password'];
            $officialemail = $datavalues['oe'];
            $lastname = strtoupper($datavalues['lastname']);
            $staffsavedpassword = base64_decode($staffsavedpassword);
            if(password_verify($password,$staffsavedpassword))
            {
                //check if password is still default
                if(password_verify($lastname,$staffsavedpassword))
                {
                    $this->session->setloginsession($this->hmiobject->getStaff()["staffid"],$officialemail, "yes");
                }
                else
                {
                    $this->session->setloginsession($this->hmiobject->getStaff()["staffid"],$officialemail, "no");
                }

                $response['status'] = "success";
                $response['message'] = "Login successfull for MIV-".$staffid;
                $responseJSON = json_encode($response);
                return $responseJSON;

            }
            else
            {
                $response['status'] = "error";
                $response['message'] = "Incorrect password for MIV-".$staffid;
                $responseJSON = json_encode($response);
                return $responseJSON;
            }
        }


    }

    public function updatePassword($oldpassword,$newpassword)
    {
        if($this->session->verifyLoginValidity() == true)
        {
            $staffid = $this->hmiobject->getStaff()["staffid"];
            $getdetailssql = "SELECT `password` FROM `hmi` WHERE staffid='$staffid'";
            $datavalues = $this->stafffb->execute_return($getdetailssql)[0];
            $staffsavedpassword = $datavalues['password'];
            $staffsavedpassword = base64_decode($staffsavedpassword);
            if(password_verify($oldpassword,$staffsavedpassword))
            {
                $password = base64_encode(password_hash($newpassword, PASSWORD_DEFAULT));
                $sql = "UPDATE `hmi` SET `password`='$password' WHERE staffid='$staffid'";
                $this->stafffb->execute_no_return($sql);
                $response['status'] = "success";
                $response['message'] = "Password successfully changed for MIV-".$staffid.", you have been logged out";
                $responseJSON = json_encode($response);
                $this->session->deleteLoginSession();
                return $responseJSON;
            }
            else
            {
                $response['status'] = "error";
                $response['message'] = "Previous password is incorrect for MIV-".$staffid;
                $responseJSON = json_encode($response);
                return $responseJSON;
            }
        }
        else
        {
            $response['status'] = "error";
            $response['message'] = "You are not logged in, please access the site properly";
            $responseJSON = json_encode($response);
            return $responseJSON;
        }

    }

    public function updateProfileimage($uri)
    {
        if($this->session->verifyLoginValidity() == true)
        {
            $staffid = $this->hmiobject->getStaff()["staffid"];
            $sql = "UPDATE `hmi` SET `img`='$uri' WHERE staffid='$staffid'";
            $this->stafffb->execute_no_return($sql);
            $response['status'] = "success";
            $response['message'] = "Profile image successfully changed for MIV-".$staffid.", you have been logged out";
            $responseJSON = json_encode($response);
            return $responseJSON;
        }
        else
        {
            $response['status'] = "error";
            $response['message'] = "You are not logged in, please access the site properly";
            $responseJSON = json_encode($response);
            return $responseJSON;
        }

    }

    public function updateProfile($lastname,$firstname,$middlename,$gender,$maritalstat,$mobileno,$personalemail,$officialemail,$residentaddress,$employmenttype,$certificate,$classofresult,$nok,$noknumber,$nokaddress,$branch,$dob,$salaryacc,$bankofacc,$pfaname,$rsapin,$resumptiondate)
    {
        if($this->session->verifyLoginValidity() == true)
        {
            $staffid = $this->hmiobject->getStaff()["staffid"];
            $fullname = $lastname." ".$firstname." ".$middlename;
            $sql = "UPDATE `hmi` SET 
            `lastname`=$lastname,
            `firstname`=$firstname,
            `middlename`=$middlename,
            `fullname`=$fullname,
            `gender`=$gender,
            `ms`=$maritalstat,
            `mn`=$mobileno,
            `pe`=$personalemail,
            `oe`=$officialemail,
            `re`=$residentaddress,
            `emp`=$employmenttype,
            `cert`=$certificate,
            `cor`=$classofresult,
            `nok`=$nok,
            `nokm`=$noknumber,
            `noka`=$nokaddress,
            `branch`=$branch,
            `dob`=$dob,
            `sacc`=$salaryacc,
            `bacc`=$bankofacc,
            `pfaname`=$pfaname,
            `rsapin`=$rsapin,
            `resdate`=$residentaddress
             WHERE staffid='$staffid'";
            $this->stafffb->execute_no_return($sql);

            $response['status'] = "success";
            $response['message'] = "Profile successfully updated for MIV-".$staffid.", you have been logged out";
            $responseJSON = json_encode($response);
            return $responseJSON;
        }
        else
        {
            $response['status'] = "error";
            $response['message'] = "You are not logged in, please access the site properly";
            $responseJSON = json_encode($response);
            return $responseJSON;
        }

    }

    public function getStaff($staffid)
    {
        if($this->session->verifyLoginValidity() == true)
        {
            $sql = "SELECT 
            `staffid`, 
            `img`, 
            `lastname`, 
            `firstname`, 
            `middlename`, 
            `fullname`, 
            `gender`, 
            `ms`, 
            `mn`, 
            `pe`, 
            `oe`, 
            `re`, 
            `dep`, 
            `des`, 
            `emp`, 
            `cert`, 
            `cor`, 
            `nok`, 
            `nokm`, 
            `noka`, 
            `branch`, 
            `dob`, 
            `sacc`, 
            `bacc`, 
            `pfaname`, 
            `rsapin`, 
            `resdate`
            FROM `hmi` WHERE staffid='$staffid'";
            $response['status'] = "success";
            $response['message'] = json_encode($this->stafffb->execute_return($sql)[0]);
            $responseJSON = json_encode($response);
            return $responseJSON;
        }
        else
        {
            $response['status'] = "error";
            $response['message'] = "You are not logged in, please access the site properly";
            $responseJSON = json_encode($response);
            return $responseJSON;
        }

    }

    public function getAllStaff()
    {
        if($this->session->verifyLoginValidity() == true)
        {
            $sql = "SELECT 
            `staffid`, 
            `img`, 
            `lastname`, 
            `firstname`, 
            `middlename`, 
            `fullname`, 
            `gender`, 
            `ms`, 
            `mn`, 
            `pe`, 
            `oe`, 
            `re`, 
            `dep`, 
            `des`, 
            `emp`, 
            `cert`, 
            `cor`, 
            `nok`, 
            `nokm`, 
            `noka`, 
            `branch`, 
            `dob`, 
            `sacc`, 
            `bacc`, 
            `pfaname`, 
            `rsapin`, 
            `resdate`
            FROM `hmi` WHERE 1";
            $response['status'] = "success";
            $response['message'] = json_encode($this->stafffb->execute_return($sql));
            $responseJSON = json_encode($response);
            return $responseJSON;
        }
        else
        {
            $response['status'] = "error";
            $response['message'] = "You are not logged in, please access the site properly";
            $responseJSON = json_encode($response);
            return $responseJSON;
        }

    }

    public function getProfileImage($staffid)
    {
        if($this->session->verifyLoginValidity() == true)
        {
            $sql = "SELECT `img` FROM `hmi` WHERE staffid='$staffid'";
            $response['status'] = "success";
            $response['message'] = json_encode($this->stafffb->execute_return($sql)[0]);
            $responseJSON = json_encode($response);
            return $responseJSON;
        }
        else
        {
            $response['status'] = "error";
            $response['message'] = "You are not logged in, please access the site properly";
            $responseJSON = json_encode($response);
            return $responseJSON;
        }

    }

    public function logout()
    {
        $this->session->deleteLoginSession();
        $response['status'] = "success";
        $response['message'] = "You have successfully been logged out";
        $responseJSON = json_encode($response);
        return $responseJSON;
    }

}