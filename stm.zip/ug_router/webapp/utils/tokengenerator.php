<?php

class tokengenerator{

    private $token = "";

    function __construct()
    {
        //Generate a random string.
        $this->token = openssl_random_pseudo_bytes(16);
        
        //Convert the binary data into hexadecimal representation.
        $this->token = bin2hex($this->token);
    }

    public function getToken()
    {
        return $this->token;
    }
}