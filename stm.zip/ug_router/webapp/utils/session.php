<?php

class session
{
    private $sessiondb = null;
    function __construct()
    {
        $this->sessiondb = new database("stm");
    }


    public function setloginsession($staffid, $officialemail, $isdefault)
    {
        $this->deleteLoginSession();
        
        $_SESSION['staffid'] = $staffid;
        $token = new tokengenerator();
        $_SESSION['token'] = $token->getToken();
        $_SESSION['logtime'] = time();
        $_SESSION['officialemail'] = $officialemail;
        $_SESSION['isdefault'] = $isdefault;

        //save to database session

            //check if login table exist
                if($this->sessiondb->execute_count_table_no_return("login") == 0)
                {
                    $tablequery = "
                    CREATE TABLE `login` ( 
                        `id` INT(16) NOT NULL AUTO_INCREMENT , 
                        `staffid` INT(16) NOT NULL , 
                        `online` VARCHAR(160) NOT NULL , 
                        PRIMARY KEY (`id`), 
                        UNIQUE (`staffid`)) ENGINE = InnoDB;";
                    $this->sessiondb->execute_no_return($tablequery);
                }

            //check if loginsession table exist
                if($this->sessiondb->execute_count_table_no_return("loginsession") == 0)
                {
                    $tablequery = "
                    CREATE TABLE `loginsession` ( 
                        `id` INT(16) NOT NULL AUTO_INCREMENT , 
                        `staffid` INT(16) NOT NULL , 
                        `token` VARCHAR(160) NOT NULL , 
                        `valid` VARCHAR(160) NOT NULL ,
                        `dos` VARCHAR(160) NOT NULL , 
                        `time` VARCHAR(160) NOT NULL , 
                        PRIMARY KEY (`id`)) ENGINE = InnoDB;";
                    $this->sessiondb->execute_no_return($tablequery);
                }

            //check if staff exist in login table
            $sql = "SELECT COUNT(*) FROM `login` WHERE staffid='$staffid'";
            if($this->sessiondb->execute_count_no_return($sql) == 0)
            {
                $sql = "INSERT INTO `login`(`staffid`, `online`) VALUES ('$staffid','yes')";
                $this->sessiondb->execute_no_return($sql);
            }
            else
            {
                $sql = "UPDATE `login` SET `online`='yes' WHERE staffid='$staffid'";
                $this->sessiondb->execute_no_return($sql);
            }

            //check loggin session
            $sql = "SELECT COUNT(*) FROM `loginsession` WHERE staffid='$staffid' AND valid='yes'";
            if($this->sessiondb->execute_count_no_return($sql) == 0)
            {
                $tokengen = new tokengenerator();
                $token = $tokengen->getToken();
                $date = date("Y-m-d ");
                $time = date("h:i:s A");
                $sql = "INSERT INTO `loginsession`(`staffid`, `token`, `valid`, `dos`, `time`) VALUES ('$staffid','$token','yes','$date','$time')";
                $this->sessiondb->execute_no_return($sql);
            }
            else
            {
                //disable previous validity and create a new session
                $tokengen = new tokengenerator();
                $token = $tokengen->getToken();
                $date = date("Y-m-d ");
                $time = date("h:i:s A");
                $sql = "UPDATE `loginsession` set valid = 'no' WHERE staffid='$staffid' AND valid='yes'";
                $this->sessiondb->execute_no_return($sql);
                $sql = "INSERT INTO `loginsession`(`staffid`, `token`, `valid`, `dos`, `time`) VALUES ('$staffid','$token','yes','$date','$time')";
                $this->sessiondb->execute_no_return($sql);
            }
    }

    public function verifyLoginValidity()
    {
        if(isset($_SESSION['staffid']) && isset($_SESSION['token']) && isset($_SESSION['logtime']))
        {
            if (time() - $_SESSION['logtime'] <= 60*60*24 ){
                return true;
             }
             else {
                $this->deleteLoginSession();
                return false;
             }
        }
        else
        {
            session_destroy();
            return false;
        }
    }

    public function deleteLoginSession()
    {
        //delete login session
        if(isset($_SESSION['staffid']))
        {
            $staffid = $_SESSION['staffid'];
            $sql = "UPDATE `login` SET `online`='no' WHERE staffid='$staffid'";
            $this->sessiondb->execute_no_return($sql);
            $sql = "UPDATE `loginsession` set valid = 'no' WHERE staffid='$staffid' AND valid='yes'";
            $this->sessiondb->execute_no_return($sql);
            unset($_SESSION['staffid']);
        }

        if(isset($_SESSION['token']))
        {
            unset($_SESSION['token']);
        }

        if(isset($_SESSION['logtime']))
        {
            unset($_SESSION['logtime']);
        }

        if(isset($_SESSION['isdefault']))
        {
            unset($_SESSION['isdefault']);
        }
    }

    
}