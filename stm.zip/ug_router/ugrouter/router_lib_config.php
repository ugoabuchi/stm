<?php
/**
router library configuration @ugoabuchi
 */
define("ug_default_main_uri", $_SERVER['REQUEST_URI']);
define("ug_https_security", false);
define("ug_default_link", "../test/home.php");
define("ug_404_link", "../test/404.php");

class router_lib_config{

    private $links = array();

    function __construct()
    {
        $this->links = 
        array(
            //pages
            "../webapp/pages/home.php" => "home",
            "../webapp/pages/hmi.php" => "hmi",


            //request
            "../webapp/requestmanager/hmirequest.php" => "hmirequest"
        );
    }

    public function getLinks()
    {
        return $this->links;
    }

    public function getDefaultMainURI()
    {
        return ug_default_main_uri;
    }

    public function getHTPSSecurity()
    {
        return ug_https_security;
    }

    public function getDefaultLink()
    {
        return ug_default_link;
    }

    public function getDefault404()
    {
        return ug_404_link;
    }
}
