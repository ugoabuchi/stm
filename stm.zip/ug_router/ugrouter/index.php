<?php
/**
router index @ugoabuchi
 */
session_start();
date_default_timezone_set("Africa/Lagos");
 //call global libraries here
include "../webapp/utils/database.php";
include "router_controller.php";
include "../webapp/utils/tokengenerator.php";
include "../webapp/utils/codegenerator.php";
include "../webapp/utils/logwriter.php";
include "../webapp/utils/session.php";

//call interface
include "../webapp/interface/hmiinterface.php";

//call controllers
include "../webapp/controller/hmicontroller.php";
//start routing
$URI = $_SERVER['REQUEST_URI'];
$BURI = explode("/", $URI);
$routename = "";

foreach($BURI as $LURI)
{
$routename = $LURI;
}

$router = new router_controller($routename, "GET");
$router->route();